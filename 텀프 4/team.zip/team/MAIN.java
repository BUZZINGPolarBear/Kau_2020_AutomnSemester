
public abstract class MAIN {
	public MAIN() {};
	public abstract void window();
}
